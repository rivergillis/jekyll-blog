-- tile_luck is gold, iron, carbon

-- todo: prev_prospected should refer to the text of the prompt. NOT THE TYPE OF TILE!

function make_prospect_prompt(tile_luck, prev_prospected)
    printh('make_prospect_prompt tile luck: ' .. table_to_str(tile_luck))

    if not contains_other_than(tile_luck, 0) then
        return make_simple_prompt({"there's nothing here."}, {'continue'}, tern(prev_prospected, 6, 3))
    end
    
    local max_luck_i = max_i(tile_luck)
    local lines = {}
    if max_luck_i == 1 then
        lines = get_gold_prospect_lines()
        lines = array_cat(lines, {'', 'it is gold.'})
    elseif max_luck_i == 2 then
        lines = get_iron_prospect_lines()
        lines = array_cat(lines, {'', 'it is iron.'})
    elseif max_luck_i == 3 then
        lines = get_carbon_prospect_lines()
        lines = array_cat(lines, {'', 'it is carbon.'})
    end

    for i,v in ipairs(tile_luck) do
        if v > 0 and i != max_luck_i then
            lines = array_cat(lines, {"there's more here."})
        end
    end

    return make_simple_prompt(lines, {'continue'}, tern(prev_prospected, 1, 2))
end

-- largest set of lines that fit
            -- "you crunch the soil and",
            -- "stones in your mouth.",
            -- "it tastes salty and",
            -- "and reminds you of home.",
            -- "and reminds you of home.",
            -- "and reminds you of homeee.",
            -- "and reminds you of homeee.",

function get_gold_prospect_lines()
    possible_lines = {
        {
            "you crunch the soil and",
            "stones in your mouth.",
            "it tastes salty and",
            "and reminds you of home.",
        },
        {
            "gold prospect ex2"
        },
    }
    return possible_lines[rnd_int(1, #possible_lines)]
end

function get_iron_prospect_lines()
    possible_lines = {
        {
            "iron prospect ex1"
        },
        {
            "iron prospect ex2"
        },
    }
    return possible_lines[rnd_int(1, #possible_lines)]
end

function get_carbon_prospect_lines()
    possible_lines = {
        {
        --  "and reminds you of homeee.",
            "you place your head on the",
            "ground and feel dozens of",
            "creatures squirming just",
            "beneath the surface. the",
            "vibrations blur your",
            "vision"
        },
        {
            "carbon prospect ex2"
        },
    }
    return possible_lines[rnd_int(1, #possible_lines)]
end

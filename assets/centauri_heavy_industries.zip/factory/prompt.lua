-- display lines, then display choice
local prompt = {}

-- each line is an aprint
-- each choice is an aprint
-- ex
-- lines = {aprint:init('line 1', 0, 10)}
-- choices = {aprint:init('Continue 0, 10+LINE_HEIGHT)}
-- prompt:init(lines, choices)
-- use make_simple_prompt if you don't want glitches / custom text

-- vertical distance between lines of text
LINE_HEIGHT = 7
-- width of a a character
CHAR_WIDTH = 4.5

function prompt:init(lines,choices)
  local p = {}
  p.lines = lines
  p.choices = choices
  assert(#choices > 0)
  assert(#lines > 0)

  -- Current line or choice we're animating
  p.current_line_aprint_i = 1
  p.current_choice_aprint_i = 1

  -- selection the cursor is on
  p.choice_cursor_i = 1

  p.rect_start_x = 0
  p.rect_start_y = 0
  p.rect_end_x = 0
  p.rect_end_y = 0
  function p:find_dims()
    local min_line_x = lines[1].x
    local min_line_y = lines[1].y
    local max_y = lines[1].y
    local max_line_len = 0
    for line in all(self.lines) do
      if #line.txt > max_line_len then
        max_line_len = #line.txt
      end
      if line.x < min_line_x then
        min_line_x = line.x
      end
      if line.y < min_line_y then
        min_line_y = line.y
      end
      if line.y > max_y then
        max_y = line.y
      end
    end

    for choice in all(self.choices) do 
      if choice.y > max_y then
        max_y = choice.y
      end
    end

    -- padding
    if min_line_x > 0 then
      min_line_x = sub_until_zero(min_line_x, 5);
    end
    if min_line_y > 0 then
      min_line_y = sub_until_zero(min_line_y, 5);
    end

    self.rect_start_x = min_line_x
    self.rect_start_y = min_line_y
    self.rect_end_y = max_y + LINE_HEIGHT + 2
    self.rect_end_x = min_line_x + (max_line_len * CHAR_WIDTH)

    return min_line_x
  end
  p:find_dims()

  -- looks for button presses
  -- returns selection index else nil
  function p:update()
    if self.current_line_aprint_i <= #self.lines then
      if self.lines[self.current_line_aprint_i]:update() then
        self.current_line_aprint_i += 1
      end
    elseif self.current_choice_aprint_i <= #self.choices then
      if self.choices[self.current_choice_aprint_i]:update() then
        self.current_choice_aprint_i += 1
      end
    end

    -- change choice 
    local new_cursor_i = self.choice_cursor_i
    if btnp(2) then -- up
      new_cursor_i = cycle_arr_rev(self.choices, self.choice_cursor_i)
    elseif btnp(3) then -- down
      new_cursor_i = cycle_arr(self.choices, self.choice_cursor_i)
    end
    self.choice_cursor_i = new_cursor_i

    for choice in all(self.choices) do
      choice.prefix = ''
    end
    self.choices[self.choice_cursor_i].prefix = '> '

    if btnp(5) then
      -- return selection if we've displayed everything
      if self.current_choice_aprint_i > #self.choices then
        return self.choice_cursor_i
      end
      -- haven't displayed everything? skip it all
      for line in all(self.lines) do
        line:skip()
      end
      for choice in all(self.choices) do
        choice:skip()
      end
      self.current_choice_aprint_i = #self.choices + 1
      self.current_line_aprint_i = #self.lines + 1
    end
  end

  function p:draw()
  -- draw box around prompt
    rectfill(self.rect_start_x, self.rect_start_y, self.rect_end_x, self.rect_end_y, 0)
    rect(self.rect_start_x, self.rect_start_y, self.rect_end_x, self.rect_end_y, 7)
  -- draw lines, choices
    for line in all(self.lines) do
      line:draw()
    end
    for choice in all(self.choices) do
      choice:draw()
    end
  end

  return p
end

-- todo: provide a speed. promprts we've seen before should be fast
function make_simple_prompt(line_strs, choice_strs, speed)
  local x = 15
  local y = 25 - LINE_HEIGHT
  local make_aprint = function(str)
    y += LINE_HEIGHT
    local line = aprint:init(str, x, y)
    line.speed = speed
    return line
  end

  local lines = foreach_ret(line_strs, make_aprint)
  y += LINE_HEIGHT
  if #choice_strs == 0 then
    choice_strs = {'continue'}
  end
  local choices = foreach_ret(choice_strs, make_aprint)

  return prompt:init(lines, choices)
end
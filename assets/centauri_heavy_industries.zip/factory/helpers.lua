NUM_MAX = 32767
function tern(cond, t, f)
    if cond then return t else return f end
end

function sat_add(a,b)
    local c = a+b 
    if (a>0) and (b>0) and (c<a or c<b) then
        return NUM_MAX
    end
    return c
end

function sub_until_zero(a,b)
    local c = a-b 
    return tern(c<0, 0, c)
end

-- rnd int from a to b inclusive
function rnd_int(a,b)
    assert(b>=a)
    return a + flr(rnd((b-a)+1))
end

-- ret next i, cycle to start
function cycle_arr(arr, i)
    i += 1
    if i > #arr then
        i = 1
    end
    return i
end

function cycle_arr_rev(arr, i)
    i -= 1
    if i < 1 then
        i = #arr
    end
    return i
end

function string_rep(s, times)
    local res = ''
    for i=1,times do
        res = res .. s
    end
    return res
end

-- given a sprite num, returns the sx,sy for sspr()
function sp_to_sxy(sp)
    return (sp % 16) * 8, (sp \ 16) * 8
end

-- sspr in sp and tile coordinates
function sspr_sp(sp, w, h, dx, dy, scale, flip_x, flip_y)
    local sx,sy = sp_to_sxy(sp)
    local sw,sh = w*8,h*8
    local dw,dh=sw,sh
    if scale != nil then 
        dw *= scale
        dh *= scale
    end
    sspr(sx,sy,sw,sh,dx,dy,dw,dh,flip_x,flip_y)
end

-- maybe index a 2d array (returns nil if first elem is nil)
function maybe_2d_idx(arr, x, y)
    if arr[x] == nil then
        return nil
    end
    return arr[x][y]
end

function str_or_nil(str)
    if str == nil then
        return 'nil'
    end
    return str
end

-- like foreach() but returns an array
function foreach_ret(tbl, f)
    local t = {}
    for k,v in pairs(tbl) do
        t[k] = f(v)
    end
    return t
end

function max_i(arr)
    local m = 0
    local max_idx = 0
    for i,v in ipairs(arr) do
        if v > m then
            m = v
            max_idx = i 
        end
    end
    return max_idx
end

function table_to_str(tbl)
    local str = ''
    for k,v in pairs(tbl) do
        str = str .. k .. '=' .. v .. ' '
    end
    return str
end

function array_cat(arr1, arr2)
    arr = {}
    local insert_fn = function(v) arr[#arr+1]=v end
    foreach(arr1, insert_fn)
    foreach(arr2, insert_fn)
    return arr
end

function contains_other_than(arr, val)
		for i,v in ipairs(arr) do
				if v ~= val then
						return true
				end
		end
		return false
end

-- Weighted random choice, returns the index
function weighted_choice(weights, weight_sum)
		local r = rnd_int(0, weight_sum)
		local upto = 0
		for i,v in ipairs(weights) do
				if upto + v >= r then
						return i
				end
				upto += v
		end

		assert(false, "weighted_choice failed")
end
local queue = {}

-- queue implemented with an array
-- it is slow

function queue:init()
	local q = {}

	q.stack = {}

	function q:push(e)
		add(self.stack, e)
	end

	function q:pop()
		local e = self.stack[1]
		deli(self.stack, 1)
		return e
	end

	function q:count()
		return #self.stack
	end

	return q
end

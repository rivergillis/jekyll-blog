local aprint = {}
local speed = 3

-- here be dragons

-- note: Must be ordered by start
-- no overlaps
-- { start: 5, stop: 13, show: "fake" }
-- txt is "abc seventeen forty five"
-- shows "abc " then "abc f"  then "abc fa"
-- ... "abc fake" .. "abc seventeen" .. "abc seventeen "
-- .. "abc seventeen f" .. "abc seventten forty five"
function aprint:init(txt,x,y,glitches)
	local a = {}
	a.txt = txt
	a.x = x
	a.y = y
	a.glitches = tern(glitches != nil, glitches, {})

	a.sub_end = 0
	a.speed = speed
	a.ticks_left = a.speed

	a.glitch_i = 1
	a.in_glitch = false
	a.glitch_show_sub_end = 0
	a.ended_glitch_prev_sub_end = 0
	a.ended_glitch = 0	-- size of messy text

	a.prefix = '' -- used by prompt.lua

	-- todo: separate update and draw
	-- ret true if we will print the entire text next update
	function a:update()
		self.ticks_left -= 1
		if self.ticks_left == 0 then
			self.ticks_left = self.speed
			if self.in_glitch then
				self.glitch_show_sub_end += 1
			else
				self.sub_end += 1
			end

			local glitch = self.glitches[self.glitch_i]
			-- check if we ended the glitch
			if self.in_glitch and self.glitch_show_sub_end > #glitch.show then
				self.in_glitch = false
				self.ended_glitch_prev_sub_end = self.sub_end
				self.sub_end = glitch.stop
				self.ended_glitch = #glitch.show
			end

			-- check if we started a glitch
			if glitch != nil and not self.in_glitch then
				-- find the next glitch with start >= now
				if self.sub_end > glitch.start then
					self.glitch_i += 1
					glitch = self.glitches[self.glitch_i]
				end
				if glitch != nil and self.sub_end == glitch.start then 
					self.in_glitch = true
					self.glitch_show_sub_end = 0
					self.sub_end -= 1
			   end
			end
		end
		return self.sub_end >= #self.txt
	end

	-- print with an extra letter
	function a:draw()
		-- show effect when ending a glitch
		if self.ended_glitch > 0 then
			local glitch = self.glitches[self.glitch_i]
			local txt = self.prefix .. sub(self.txt, 1, self.ended_glitch_prev_sub_end) .. string_rep('*', self.ended_glitch)
			print(txt, self.x, self.y)
			self.ended_glitch -= rnd_int(4,6)
		end
		if self.in_glitch then
			local glitch = self.glitches[self.glitch_i]
			local txt = self.prefix .. sub(self.txt, 1, self.sub_end) .. sub(glitch.show, 1, self.glitch_show_sub_end)
			print(txt, self.x, self.y)
		else
			print(self.prefix .. sub(self.txt, 1, self.sub_end), self.x, self.y)
		end
	end

	function a:skip()
		self.ticks_left = -1 -- stop updating
		self.in_glitch = false
		self.ended_glitch = -1
		self.sub_end = #self.txt
	end

	return a
end


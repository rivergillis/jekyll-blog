function tbl_contains_arr(tbl, arr)
	for _, v in pairs(tbl) do
		if arr_equal(v, arr) then
			return true
		end
	end

	return false
end

-- only 1-indexed
function arr_copy(tbl)
	local t = {}

	for _, v in pairs(tbl) do
		add(t, v)
	end

	return t
end

function arr_equal(lhs,rhs)
	for i = 1,#lhs do
		if lhs[i] != rhs[i] then
			return false
		end
	end
	return #lhs == #rhs
end
START_SCENE_NUM = 5 -- todo: set to 1

-- x,y means the center of the object in map tiles
-- TODO: Index factories by [x][y] for fast lookup
factories = {}
player = {
	x = 4,
	y = 4,
	dx = 0,
	dy = 0,
	tbar_i = 1,
	gold = 0,
	iron = 0,
	carbon = 0,
	-- Move when ticks_left == 0
	ticks_left = 0
}
tbar = {}
-- Keyed by un-selected sprite num.
tbar_meta = {}

-- 2D tile_luck[x][y] = {g,i,c} for x,y map tiles.
tile_luck = {}
tile_luck_sum = {}
prospected = {}	-- 2d per tile, true if prospected. prospect all types at once

-- map from sprite to elem type for flagged sprite
flag_type = {}

state = {
	scene_num = 1,	-- use 0 for 'no scene' or the main game
	aprints = {},
	prompt = nil, -- todo, add prompt class
}

-- read only tables
elem_types = {
	"gold",
	"iron",
	"carbon",
}

function _init()
	init_flag_type()
	set_tbar(1, true, 54, prospect)
	set_tbar(2, true, 49, make_factory)
	set_tbar(3, false, 0, nil)
	set_tbar(4, false, 0, nil)
	set_tbar_meta()
	init_luck()
	init_prospected()
	state.scene_num = START_SCENE_NUM
	-- state.prompt = make_simple_prompt({'this is a prompt', 'second line'}, {'continue', 'cancel'})
end

function init_flag_type()
	flag_type[25] = 1 -- iron
	flag_type[26] = 2 -- gold
	flag_type[27] = 3 -- carbon
end

function init_luck()
	for x = 0,127 do
		tile_luck[x] = {}
		for y = 0,31 do
			tile_luck[x][y] = {0,0,0}
		end
	end

	for x = 0,127 do
		for y = 0,31 do
			local sprite = mget(x,y)
			if fget(sprite,0) then
				init_luck_from(x,y,flag_type[sprite])
				mset(x,y,0)
			end
		end
	end

	for x=0,127 do
		tile_luck_sum[x] = {}
		for y=0,31 do
			local tluck = tile_luck[x][y]
			tile_luck_sum[x][y] = tluck[1] + tluck[2] + tluck[3]
		end
	end
end

function init_prospected()
	for x = 0,127 do
		prospected[x] = {}
	end
end

function in_bounds(x,y)
	return x >= 0 and x <= 127 and y >= 0 and y <= 31
end

function init_luck_from(x,y,i)
	-- bfs and track depth
	local seen = {{x,y}} -- {x,y}
	local q = queue:init()
	if in_bounds(x,y) then
		q:push({x,y,0})
	end
	while q:count() > 0 do
		local xyd = q:pop()
		-- go up to 10 levels deep
		if xyd[3] >= 10 then goto continue end

		-- todo: adjust
		-- note: this will go OOB if start search near edge
		tile_luck[xyd[1]][xyd[2]][i] = 40 - xyd[3]

		local eval_dir = function (x,y,d)
			if in_bounds(x,y) and not tbl_contains_arr(seen, {x,y}) then
				add(seen, {x,y})
				q:push({x,y,d})
			end
		end
		eval_dir(xyd[1],xyd[2]-1,xyd[3]+1) -- up
		eval_dir(xyd[1],xyd[2]+1,xyd[3]+1) -- down
		eval_dir(xyd[1]-1,xyd[2],xyd[3]+1) -- left
		eval_dir(xyd[1]+1,xyd[2],xyd[3]+1) -- right

		::continue::
	end
end

function set_tbar(tbar_i, enabled, sprite, fn)
	-- enabled = "can select"
	tbar[tbar_i] = {enabled=enabled, sprite=sprite, fn=fn}
end

function prospect()
	local x = ceil(player.x)
	local y = ceil(player.y)
	prev_prospected = maybe_2d_idx(prospected, x, y)
	prospected[x][y] = true
	local tluck = tile_luck[x][y]
	state.prompt = make_prospect_prompt(tluck, prev_prospected)
    
	-- change map tile to prospected sprite
	if not contains_other_than(tluck, 0) then return end
	local max_luck_i = max_i(tluck)
	local luck_amt = tluck[max_luck_i]
	printh('max luck is ' .. max_luck_i)
	if max_luck_i == 1 then
		mset(x,y,tern(luck_amt > 20,42,43))
	elseif max_luck_i == 2 then
		mset(x,y,tern(luck_amt > 20,58,59))
	elseif max_luck_i == 3 then
		mset(x,y,45)
	end
end

function harvest(x,y)
	local luck_i = weighted_choice(tile_luck[x][y], tile_luck_sum[x][y])
	local luck = tile_luck[x][y][luck_i]
	local amount = flr(rnd(luck))
	local type = elem_types[luck_i]
	player[type] = sat_add(player[type], amount)
end

function harvest_all(x,y)
	local tluck = tile_luck[x][y]
	for i=1,#elem_types do
		local amount = rnd_int(0, tluck[i])
		printh('tluck[i] is ' .. tluck[i] .. ' so amount was ' .. amount)
		local type = elem_types[i]
		player[type] = sat_add(player[type], amount)
	end
end

function player_harvest() 
	if not in_bounds(player.x, player.y) then return end
	harvest(ceil(player.x), ceil(player.y))
end

function destroy_factory()
	-- todo: do some min dist() to player
	local found_i = nil
	for i = 1,#factories do
		local f = factories[i]
		if ceil(f.x) == ceil(player.x) and ceil(f.y) == ceil(player.y) then
			found_i = i
			break
		end
	end

	if found_i != nil then
		deli(factories, found_i)
	end
end

function make_factory()
	-- todo: sprite based on type,upgrades
	fact = {
		x=ceil(player.x),
		y=ceil(player.y),
		sprite=8,
		ticks_left = 10,
	}
	add(factories, fact)
	return fact
end

function update_moving_fact(fact)
	-- move in set direction. If we hit an obstacle then change
	-- the set direction.
	local new_x = fact.x + fact.dx
	local new_y = fact.y + fact.dy
	if not in_bounds(new_x, new_y) or hits_obstacle(new_x, new_y) then
		set_random_direction(fact)
	else
		fact.x = new_x
		fact.y = new_y
	end
end

function try_spawn_organic(fact)
	-- look around us for a free spot. TODO
end

function update_organic_fact(fact)
	-- low chance to spawn a new organic fact if there's a free space surrounding us
	if rnd(1) > 0.95 then
		try_spawn_organic(fact)
	end

	harvest(fact.x, fact.y)
end

function update_factory(fact)
	if fact.sprite == 10 then	-- moving
		update_moving_fact(fact)
	end

	fact.ticks_left -= 1
	if fact.ticks_left > 0 then return end
	fact.ticks_left = rnd_int(60, 120)

	if fact.sprite == 8 then		-- basic
		harvest(ceil(fact.x), ceil(fact.y))
	elseif fact.sprite == 9 then	-- multi
		harvest_all(ceil(fact.x), ceil(fact.y))
	elseif fact.sprite == 10 then	-- moving
		harvest(ceil(fact.x), ceil(fact.y))
	elseif fact.sprite == 11 then	-- organic
		update_organic_fact(fact)
	end

end

function move_in_bounds(xy,new_x,new_y)
	-- can we move in x?
	if in_bounds(new_x,xy.y) then
		xy.x = new_x
	end
	-- can we move in y?
	if in_bounds(xy.x, new_y) then
		xy.y = new_y
	end
end

function update_player()
	-- if dx/dy is 0 then set ticks_left to 0
	-- this makes the player more responsive to movement
	if player.dx == 0 and player.dy == 0 then
		player.ticks_left = 0
	elseif player.ticks_left == 0 then
		move_in_bounds(player, player.x + player.dx, player.y + player.dy)
		player.dx = 0
		player.dy = 0
		player.ticks_left = 2
	else
		player.ticks_left -= 1
	end
end

function update_tbar()
	for i=1,4 do
		set_tbar(i, false, 0, nil)
	end

	local fact = get_factory(ceil(player.x),ceil(player.y))
	-- on a factory, show upgrade options + delete
	if fact then
		if fact.sprite == 8 then	-- basic factory
			set_tbar(1, true, 51, upgrade_multi)
			set_tbar(2, true, 52, upgrade_moving)
			set_tbar(3, true, 53, upgrade_organic)
			set_tbar(4, true, 50, destroy_factory)
		else
			set_tbar(1, true, 50, destroy_factory)
		end
		return
	end
	-- no factory, we can create or manual harvest (if prospected)
	if maybe_2d_idx(prospected,ceil(player.x),ceil(player.y)) then
		set_tbar(1, true, 48, player_harvest)
	else 
		set_tbar(1, true, 54, prospect)
	end
	set_tbar(2, true, 49, make_factory)
	-- if fact then printh(fact.x .. ' ' .. fact.y) end
end

function fix_tbar_selection()
	local i = player.tbar_i
	while not tbar[i].enabled do
		i = cycle_arr(tbar, i)
	end
	player.tbar_i = i
end

function cycle_tbar()
	local i = player.tbar_i
	i = cycle_arr(tbar, i)

	while not tbar[i].enabled do
		i = cycle_arr(tbar, i)
	end
	player.tbar_i = i
end

function activate_tbar()
	tbar[player.tbar_i].fn()
end

function update_prompt()
	selection = state.prompt:update()
	if selection != nil then
		printh('removing prompt')
		state.prompt = nil
	end
end

function _update()
	if state.prompt then
		return update_prompt()
	end

	if state.scene_num != 0 then
		return update_scene()
	end

	-- check inputs here
	-- reset dx/dy here to avoid double-moves
	player.dx = 0
	player.dy = 0
	if btn(0) then player.dx = -1.0 end
	if btn(1) then player.dx = 1.0 end
	if btn(2) then player.dy = -1.0 end
	if btn(3) then player.dy = 1.0 end

	update_player()
	update_tbar()
	fix_tbar_selection()

	if btnp(4) then	-- O: z,c,n
		cycle_tbar()
	end

	if btnp(5) then	-- X: x,v,m
		activate_tbar()
	end
	foreach(factories,update_factory)
end

function draw_player()
	local sx = (player.x * 8)
	local sy = (player.y * 8)
	spr(1, sx, sy)
end

function draw_factory(fact)
	local sx = (fact.x * 8)
	local sy = (fact.y * 8)
	spr(fact.sprite, sx, sy)
end

function draw_toolbar()
	color(0)
	rectfill(0,116, 128, 128)
	color(6)
	-- highlight offset: 20
	local x = 93
	for i = 1,#tbar do
		local s = tbar[i].sprite
		s = tern(player.tbar_i == i,s+20,s)
		spr(s, x, 120)
		x += 9
	end

	-- tbar text
	local s = tbar[player.tbar_i].sprite
	local meta = tbar_meta[s]
	if not meta then return end
	print(meta.txt, 0, 116)
	-- skip values for some types
	if s == 54 or s == 48 then return end
	print(meta.gold_c .. "g", 0, 123)
	print(meta.iron_c .. "i", 30, 123)
	print(meta.carbon_c .. "c", 60, 123)
end

function draw_header()
	color(0)
	rectfill(0,0, 128, 13)
	color(6)
	print('wealth:', 0, 1)
	print(player.gold .. "g", 30, 1)
	print(player.iron .. "i", 60, 1)
	print(player.carbon .. "c", 90, 1)
	print('efficiency: 99.7000% / 99.8000%', 0, 8)
	-- print('demise in 3:00:00', 0, 15)
	-- tile_luck 41 -> 555
	-- print('mem ' .. stat(0) .. ' /2048', 0, 15)
end

function dbg_draw_luck()
some_var = {}
	-- todo: this is incredibly expensive
	-- create get_tiles_near_player() ?
	local tile_x = 0
	local tile_y = 0
	for x = 0,1023,8 do
		for y = 0,255,8 do
			tile_x = ceil(x/8)
			tile_y = ceil(y/8)
			pset(x,y,tile_luck[tile_x][tile_y][1])
			pset(x,y+2,tile_luck[tile_x][tile_y][2])
			pset(x,y+4,tile_luck[tile_x][tile_y][3])
		end
	end
end

function dbg_draw()
	print('x' .. player.x .. ' y' .. player.y, 0, 40)
end

function draw_prompt()
	if state.prompt then
		state.prompt:draw()
	end
end

function _draw()
	cls()
	if state.scene_num != 0 then
		return draw_scene()
	end
	
	-- Put the player in the middle of the screen
	camera(player.x*8-64,player.y*8-64)
	
	map()

	draw_player()
	foreach(factories,draw_factory)

	-- dbg_draw_luck()

	-- UI goes after camera reset
	camera()
	draw_toolbar()
	draw_header()
	-- dbg_draw()
	draw_prompt()
end

function set_random_direction(fact)
	if rnd_int(0,1)==1 then
		fact.dx = rnd(0.4) + 0.1
		fact.dy = 0
	else
		fact.dx = 0
		fact.dy = rnd(0.4) + 0.1
	end

	if rnd_int(0,1)==1 then
		fact.dx *= -1
		fact.dy *= -1
	end
end

function upgrade_multi()
	local fact = get_factory(ceil(player.x),ceil(player.y))
	fact.sprite = 9
end

function upgrade_moving()
	local fact = get_factory(ceil(player.x),ceil(player.y))
	fact.sprite = 10
	set_random_direction(fact)
end

function upgrade_organic()
	local fact = get_factory(ceil(player.x),ceil(player.y))
	fact.sprite = 11
end

function get_factory(x,y)
	-- todo: index by x,y
	for fact in all(factories) do
		if fact.x == x and fact.y == y then return fact end
	end
	return nil
end

function draw_scene_chars()
	sspr_sp(84, 4, 4, 0, 30, 2)
	sspr_sp(88, 4, 4, 64, 30, 2)
	-- todo: replace eyes, change palette, optionally disable one...
end

function draw_scene()
	-- todo: draw the scene
	for a in all(state.aprints) do
		a:draw()
	end

	if state.scene_num == 1 then -- main menu
		print('main menu\nUSE z, x, AND arrow keys TO PLAY\npress z to start', 0, 100)
	elseif state.scene_num == 2 then
		draw_scene_chars()
	elseif state.scene_num == 3 then
		draw_scene_chars()	
	elseif state.scene_num == 4 then
		draw_scene_chars()	
	end
end

function update_scene()
	local aprints_done = true
	for a in all(state.aprints) do
		aprints_done = aprints_done and a:update()
	end
	if aprints_done then
		if btnp(4) then	-- O: z,c,n
			state.scene_num += 1
			state.aprints = {}

			if state.scene_num == 2 then
				add(state.aprints, aprint:init('...\n      ...\n            it is awake.', 0, 100,glitches))
			elseif state.scene_num == 3 then
				add(state.aprints, aprint:init('listen closely child ...',0,100))
			elseif state.scene_num == 4 then
				local glitches = {{start=8,stop=10,show='centauri heavy industri'}}
				add(state.aprints, aprint:init('we are god\nand we have given you life.',0,100,glitches))
			end
		end
	end

	-- note: make this a later scene (do some story stuff later)
	if state.scene_num == 5 then
		state.scene_num = 0
		state.aprints = {}
	end
end

function hits_obstacle(x,y) 
	return false	-- todo
end

function set_tbar_meta()
	tbar_meta[48] = {
		txt = "harvest resources",
		gold_c = 0,
		iron_c = 0,
		carbon_c = 0
	}
	tbar_meta[49] = {
		txt = "construct factory",
		gold_c = 0,
		iron_c = 100,
		carbon_c = 0
	}
	tbar_meta[50] = {
		txt = "destroy factory",
		gold_c = 0,
		iron_c = 0,
		carbon_c = 0
	}
	tbar_meta[51] = {
		txt = "upgrade: multi-factory",
		gold_c = 0,
		iron_c = 0,
		carbon_c = 0
	}
	tbar_meta[52] = {
		txt = "upgrade: moving factory",
		gold_c = 0,
		iron_c = 0,
		carbon_c = 0
	}
	tbar_meta[53] = {
		txt = "upgrade: organic factory",
		gold_c = 0,
		iron_c = 0,
		carbon_c = 0
	}
	tbar_meta[54] = {
		txt = "prospect",
		gold_c = 0,
		iron_c = 0,
		carbon_c = 0
	}
end

-- notes:

-- fact upgrade paths
-- basic fact
--		multi-fact: hits every luck at once
--		moving-fact: moves across the map and mines
--		organic-fact (req carbon): grows on its own
--
--  create drone -> reveals nearby luck
--
--	create life	-> walks to carbon and mines it
--		order shrine  -> does nothing?
--		order village -> creates some houses and factories

-- BEFORE RELEASE:
-- remove all asssert() :)
